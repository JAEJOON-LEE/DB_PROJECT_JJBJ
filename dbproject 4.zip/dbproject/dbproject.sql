SELECT DISTINCT t.P_ID, i.PNAME, i.PRICE, sum(c.QUANT) 
FROM TEMP12 t, ITEMS i,current_quant_check c 
WHERE t.P_ID = i.PID and i.PID = c.P_ID 
GROUP BY c.P_ID;

create view temp13 as
select



select * from temp12;

select P_ID from temp12;
select * from current_quant_check;

select * from ITEMS;

select DISTINCT PID, PNAME, PRICE
FROM ITEMS
WHERE PID in (select P_ID from temp12);


DROP view temp13;

create view temp13 as 
select PID, SUM(QUANT) as AQ
FROM ITEMS
WHERE PID in (select P_ID from temp12)
GROUP BY PID;


create table TOTAL(
	PID INT NOT NULL,
	AQ INT NOT NULL DEFAULT 0
);

select * from temp13;

select DISTINCT i.PID, i.PNAME, i.PRICE, t.AQ
FROM ITEMS i, temp13 t
WHERE i.PID = t.PID;





select * from customer;

1d680x1304499
SELECT t.P_ID, i.PRICE, SUM(i.QUANT) AS AQ FROM TEMP12 t, ITEMS i where t.P_ID=i.PID GROUP BY i.PID;

desc items;

show tables;

create table shoppingBag(
	c_ID INT NOT NULL,
	P_ID INT NOT NULL,
	P_qaunt INT NOT NULL DEFAULT 0
);


create table order_detail2(
	c_ID INT NOT NULL,
	P_ID INT NOT NULL,
	P_quant int not null default 0,
	p_price int not null,
	order_date date not null
);
	


delete from shooppingBag where P_ID = 1;

select * from shoppingBag;

delete from shoopingBag
where P_ID = 1;

desc shoppingBag;

show tables;

SELECT P_ID, P_quant, P_price, order_date FROM ORDER_DETAIL2 WHERE C_ID = 1;


show tables;

select * from current_quant_check;

select * from temp13;